Thanks for downloading one of our freebies.
-------------------------------------------

You can fine more at http://bootstrapee.com
Check out the license page at http://bootstrapee.com/blog/2013/11/20/license-faq/