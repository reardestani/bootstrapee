(function($) {
  "use strict";

  // Define variables fr freewall
  var freewallContainer = $("#freewall"),
  		dataAnimate =  freewallContainer.data("animate"),
  		dataCellW =  freewallContainer.data("cellWidth"),
  		dataCellH = freewallContainer.data("cellHeight"),
  		dataGutterX = freewallContainer.data("gutterX"),
  		dataGutterY = freewallContainer.data("gutterY");
	
	// Freewall init
	var ewall = new freewall("#freewall");
	ewall.reset({
		selector: '.item',
		animate: dataAnimate,
		cellW: dataCellW,
		cellH: dataCellH,
		gutterX: dataGutterX,
		gutterY: dataGutterY,
		onResize: function() {
			ewall.fitWidth();
		}
	});
	ewall.fitWidth();

	// for scroll bar appear;
	$(window).trigger("resize");

	// Fix some height issue after grid
	$('.item img').css('height', '100%');

	// Fix overlapping item meta with footer
	var marginBottom = $('#primary').data("marginBottom");
	$('#primary').css('margin-bottom', marginBottom)

})(jQuery);