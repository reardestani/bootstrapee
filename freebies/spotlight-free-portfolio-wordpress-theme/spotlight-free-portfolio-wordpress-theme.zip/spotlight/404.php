<?php
/**
 * The template for displaying 404 pages (Not Found).
 *
 * @package Spotlight
 */

get_header(); ?>

	<div id="primary" class="content-area <?php echo get_theme_mod( 'body_container' ); ?>">
		<main id="main" class="site-main" role="main">

			<section class="error-404 not-found text-center">
				<div class="post-divider"></div>
				<header class="page-header">
					<p><?php _e( '404', 'spotlight' ); ?></p>
					<h3 class="page-title"><?php _e( 'Oops! That page can&rsquo;t be found.', 'spotlight' ); ?></h3>
				</header><!-- .page-header -->

				<div class="page-content">
					<p><?php _e( 'It looks like nothing was found at this location. Recheck the URL.', 'spotlight' ); ?></p>

				</div><!-- .page-content -->
			</section><!-- .error-404 -->

		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_footer(); ?>