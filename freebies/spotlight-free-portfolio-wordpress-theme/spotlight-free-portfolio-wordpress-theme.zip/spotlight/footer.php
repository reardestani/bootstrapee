<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Spotlight
 */
?>

		</div><!-- #content -->

		<footer id="colophon" class="site-footer" role="contentinfo">
			<div class="site-info <?php echo get_theme_mod( 'body_container' ); ?>">
				<nav class="footer-navigation" role="navigation">
					<?php wp_nav_menu( array( 
						'theme_location' 	=> 'footer', 
						'container' 			=> 'ul', 
						'items_wrap' 			=> '<ul class="list-inline">%3$s</ul>', 
						'link_after'      => '.',
					) ); ?>
				</nav><!-- #site-navigation -->

				<?php do_action( 'spotlight_credits' ); ?>
				<p><?php echo get_theme_mod( 'footer_copyright' ); ?></p>
			</div><!-- .site-info -->
		</footer><!-- #colophon -->
	</div><!-- #page -->

	<?php wp_footer(); ?>

	</body>
</html>