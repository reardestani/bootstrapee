Spotlight
=========

Spotlight is a Premium WordPress Theme worth $40 but we decided to share it for free in here, Bootstrapee.

It is a minimal, clean and easy-to-use WordPress theme. Our main purpose of this theme is simplicity. We have removed all the unnecessary features from this theme and provide a really easy and simple portfolio WordPress theme.

Read more at http://bootstrapee.com

Happy enjoying.

Good luck!
